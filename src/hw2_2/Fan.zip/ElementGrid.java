package hw2_2;

import java.awt.Color;

public class ElementGrid {
	private int pattern;
	private Color color;
	private boolean isMidAir;
	private boolean updated;
	
	public boolean isUpdated() {
		return updated;
	}
	public void setUpdated(boolean updated) {
		this.updated = updated;
	}
	public ElementGrid() {
		super();
		// TODO Auto-generated constructor stub
		isMidAir=false;
		pattern=-1;
		color=Color.BLACK;
		updated=true;

	}
	public boolean isMidAir(){
		return isMidAir;
	}
	public void setIsMidAir(Boolean isMoving){
		this.isMidAir=isMoving;
	}
	public int getPattern() {
		return pattern;
	}
	public void setPattern(int pattern) {
		this.pattern = pattern;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public void clearGrid(){
		this.pattern=-1;
		color=Color.BLACK;
		isMidAir=false;
		updated=true;
	}
	
}
