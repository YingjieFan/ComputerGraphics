package hw2_2;

import java.util.TimerTask;

public class FrameUpdateTask extends TimerTask{
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
